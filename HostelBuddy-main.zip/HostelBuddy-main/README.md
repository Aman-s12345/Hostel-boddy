# HostelBuddy


## Inspiration
A few days ago, on my friend's birthday, I wasn't able to get any speakers. So an idea came into my mind. That there should be something that can help people borrow things from others easily. So I and my friends thought of creating a website that could serve our needs, so we created this website, HostelBuddy. Which can help us to lend and borrow things among ourselves.


## What it does
By using our website, we can lend things like food, medicine, clothes, shoes and many others. This site can be very useful for people in emergencies.
For example, if a person has a sudden fever or headache in the night when he can't access any medical shops, in that scenario, our website can be very useful as
He or she can directly find any available medicines among the students. This can be very useful.
We can use this website to help students who are in need of a particular thing or medicine.
etc., we also inculcate in our students the feeling of sharing among ourselves, which enhances their social skills. By this website, we can connect the students of our college on a single platform where each one can help others and get helped themselves.


## How we built it
For creating this website we have mostly used nodeJs, it's framework expressJs. We have used SQL for database management. Then we have used HTML, CSS, JavaScript.


## Challenges we ran into
As we  have just reached our second year, we were not very confident that we would be able to complete this project as the 
 required were not well known to us. The time was also less as we had to first learn and then execute it. We were quite skeptical about our idea but our friend and seniors appreciated us 
and encouraged us to work on this idea. So we took up this Challenge and tried our level best to complete our project. While creating this project we were stuck many times specially in the backend part but we somehow tackled them.


## Accomplishments that we're proud of 
As we are just entering our third semester, we don't know many things.But this time-bound project has let us learn many things, and we are so proud to complete the project within 48 hours.
which was quite tough.


## What we learned
We got to know the importance of teamwork and also got to learn new technolgies nodejs,sql,php,expressjs.


## What's next
we would like make our website look more attartive and responsive. We would also like to make use of the database more effectively. And first of all, we would like to reduce the bugs in the website which occur mainly due to the backend part. We would also like to improve the backend part.
We are also planning to take our project forward in the real life application and HELP THE SOCIETY.
